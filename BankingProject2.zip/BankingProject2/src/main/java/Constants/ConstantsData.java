package Constants;

public class ConstantsData {
	
	public final static String PropertyFilePath = "src/main/java/Constants/Global.properties";
	public final static String ExcelFilePath = "C:\\selenium_java\\TestDataURL.xlsx";
}
